.PY TO GENERATE

make_noisy - LAB 2 (and irurun lang is yung make_noisy.py for LAB 2)
- clean_ocr.py

pipeline.py - LAB 3 (ang irurun lang is yung pipeline.py for LAB 3)
- trocr_handwritten.py
- trocr_printed.py

ocr_spacy.py - LAB 4 (ang irurun lang is yung ocr_spacy.py for LAB 4)

ENSURE TO HAVE APPROARIATE ENVIRONMENT

uv pip install torch torchvision
uv pip install transformers
uv pip install easyocr
uv pip install datasets
uv pip install Pillow
uv pip install opencv-python
uv pip install nltk
uv pip install spacy

spaCY model
python -m spacy download en_core_web_sm

NLTK resources
python -m nltk.downloader stopwords punkt punkt_tab


