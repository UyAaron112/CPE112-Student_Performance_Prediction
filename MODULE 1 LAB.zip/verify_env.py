import sys
import torch
import easyocr
import transformers
import nltk
import spacy

print(f"Python version: {sys.version}")
print(f"PyTorch version: {torch.__version__}")
print("EasyOCR imported successfully")
print(f"Transformers version: {transformers.__version__}")
print(f"NLTK version: {nltk.__version__}")
print(f"spaCy version: {spacy.__version__}")
print("\nEnvironment verification complete!")