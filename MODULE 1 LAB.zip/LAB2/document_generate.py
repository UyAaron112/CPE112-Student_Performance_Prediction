from PIL import Image, ImageDraw, ImageFont
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
out_dir  = os.path.join(BASE_DIR, "lab4_docs")
os.makedirs(out_dir, exist_ok=True)

def get_font(size=24):
    try:
        return ImageFont.truetype("cour.ttf", size)
    except:
        return ImageFont.load_default()

def make_doc_image(doc_name, lines, font_size=24):
    font    = get_font(font_size)
    padding = 30
    line_h  = font_size + 14
    width   = 900

    # ── Save full document image ──
    height = padding * 2 + line_h * len(lines)
    img    = Image.new("RGB", (width, height), color=(255, 255, 255))
    draw   = ImageDraw.Draw(img)
    for i, line in enumerate(lines):
        draw.text((padding, padding + i * line_h), line, fill=(0, 0, 0), font=font)
    img.save(os.path.join(out_dir, f"{doc_name}.png"))
    print(f"Saved: {doc_name}.png")

    # ── Save each line as a separate image ──
    lines_dir = os.path.join(out_dir, f"{doc_name}_lines")
    os.makedirs(lines_dir, exist_ok=True)
    for i, line in enumerate(lines):
        line_img  = Image.new("RGB", (width, line_h + 10), color=(255, 255, 255))
        line_draw = ImageDraw.Draw(line_img)
        line_draw.text((padding, 5), line, fill=(0, 0, 0), font=font)
        line_img.save(os.path.join(lines_dir, f"line_{i:02d}.png"))
    print(f"  -> {len(lines)} line images saved to {doc_name}_lines/")

# ── Document 1: Business Invoice ─────────────────────────────
make_doc_image("doc1_invoice", [
    "INVOICE #2026-001",
    "Date: January 13, 2026",
    "Bill To: John Smith",
    "Company: Mapua University",
    "Location: Manila, Philippines",
    "Amount Due: $500.00",
    "Due Date: February 1, 2026",
])

# ── Document 2: News Article ──────────────────────────────────
make_doc_image("doc2_news", [
    "Microsoft CEO Satya Nadella visited Manila last Monday.",
    "He met with officials from the University of the Philippines.",
    "The meeting took place on January 10, 2026.",
    "A deal worth $2 million was announced.",
    "Google and Amazon were also present at the summit.",
])

# ── Document 3: Legal Form ────────────────────────────────────
make_doc_image("doc3_legal", [
    "LEGAL AGREEMENT",
    "Party A: Maria Santos",
    "Party B: Accenture Philippines",
    "Date of Agreement: December 5, 2025",
    "Location: Bonifacio Global City, Taguig",
    "Compensation: PHP 150000.00",
    "Witness: Jose Reyes",
])

print("\nAll documents and line images saved to lab4_docs/")