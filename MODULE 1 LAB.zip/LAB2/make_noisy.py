# step6_make_noisy.py
import cv2
import numpy as np
import os
import easyocr

print("Generating noisy images...")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

images = [
    os.path.join(BASE_DIR, "clean1.png"),
    os.path.join(BASE_DIR, "clean2.png"),
    os.path.join(BASE_DIR, "clean3.png"),
]

output_dir = os.path.join(BASE_DIR, "noisy_output")
os.makedirs(output_dir, exist_ok=True)

def salt_pepper(image, prob=0.02):
    noisy = image.copy()
    h, w = noisy.shape[:2]

    num_salt = int(prob * h * w)
    sy = np.random.randint(0, h, num_salt)
    sx = np.random.randint(0, w, num_salt)
    noisy[sy, sx] = 255

    num_pepper = int(prob * h * w)
    py = np.random.randint(0, h, num_pepper)
    px = np.random.randint(0, w, num_pepper)
    noisy[py, px] = 0

    return noisy

for img_path in images:
    img = cv2.imread(img_path)

    if img is None:
        print(f"Cannot read {img_path}. Check file path.")
        continue

    # Get just the filename without extension e.g. "clean1"
    base = os.path.splitext(os.path.basename(img_path))[0]

    # 1️⃣ Gaussian Blur
    blur = cv2.GaussianBlur(img, (5, 5), 0)
    cv2.imwrite(os.path.join(output_dir, f"{base}_blur.png"), blur)

    # 2️⃣ Salt & Pepper
    sp = salt_pepper(img)
    cv2.imwrite(os.path.join(output_dir, f"{base}_sp.png"), sp)

    # 3️⃣ Low Contrast
    low = cv2.convertScaleAbs(img, alpha=0.5, beta=0)
    cv2.imwrite(os.path.join(output_dir, f"{base}_contrast.png"), low)

    print(f"Processed {base}.png  →  {base}_blur.png | {base}_sp.png | {base}_contrast.png")

print(f"\n All noisy images saved to: {output_dir}")

GROUND_TRUTH = {
    "clean1": "TITANS",   
    "clean2": "TITANIC",   
    "clean3": "DOLL",   
}

print("\nLoading EasyOCR model...")
reader = easyocr.Reader(['en'], gpu=False)
print("Model ready!\n")

def run_ocr(image_path):
    results = reader.readtext(image_path)
    if not results:
        return "", 0.0
    text = " ".join(r[1] for r in results)
    conf = float(np.mean([r[2] for r in results]))
    return text, round(conf, 3)

def classify_error(prediction, ground_truth, confidence):
    if not prediction or confidence == 0.0:
        return "Detection failure"
    if prediction.upper() == ground_truth.upper():
        return "None"
    if len(prediction) < len(ground_truth) * 0.6:
        return "Missed characters"
    return "Character substitution"

all_images = []
for i in range(1, 4):
    gt = GROUND_TRUTH[f"clean{i}"]
    all_images += [
        ("Clean Printed",   os.path.join(BASE_DIR,  f"clean{i}.png"),          gt, f"IIIT5K Sample {i}"),
        ("Gaussian Blur",   os.path.join(output_dir, f"clean{i}_blur.png"),    gt, f"IIIT5K Sample {i}"),
        ("Salt-and-Pepper", os.path.join(output_dir, f"clean{i}_sp.png"),      gt, f"IIIT5K Sample {i}"),
        ("Low Contrast",    os.path.join(output_dir, f"clean{i}_contrast.png"),gt, f"IIIT5K Sample {i}"),
    ]

print(f"{'No.':<4} {'Image Type':<18} {'Source':<16} {'Ground Truth':<14} {'Prediction':<16} {'Conf':>5}  {'Error Type'}")
print("-" * 100)

results_data = []
for idx, (img_type, img_path, gt, source) in enumerate(all_images, 1):
    prediction, conf = run_ocr(img_path)
    error            = classify_error(prediction, gt, conf)
    print(f"{idx:<4} {img_type:<18} {source:<16} {gt:<14} {prediction:<16} {conf:>5.2f}  {error}")
    results_data.append((img_type, source, gt, prediction, conf, error))

print("\n")
print("=" * 60)
print("AVERAGE CONFIDENCE PER CONDITION")
print("=" * 60)

for condition in ["Clean Printed", "Gaussian Blur", "Salt-and-Pepper", "Low Contrast"]:
    scores = [c for (t, _, _, _, c, _) in results_data if t == condition]
    avg    = round(sum(scores) / len(scores), 3) if scores else 0.0
    print(f"  {condition:<20} →  {avg}")

print("\n Done! All results printed above.")