import shutil

shutil.unpack_archive(
    r'C:\Users\renpg\Downloads\IIIT5K-Word_V3.0.tar.gz',
    r'C:\Users\renpg\LocalRepo\venvs\cpe179p\mod1Lab\data'
)

print("Extracted successfully!")
