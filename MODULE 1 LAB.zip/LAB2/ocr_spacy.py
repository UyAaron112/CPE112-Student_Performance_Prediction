import os
import warnings
warnings.filterwarnings("ignore", message="'pin_memory'")

import spacy
from transformers import TrOCRProcessor, VisionEncoderDecoderModel
from PIL import Image

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DOCS_DIR = os.path.join(BASE_DIR, "lab4_docs")

print("Loading TrOCR printed model...")
processor = TrOCRProcessor.from_pretrained("microsoft/trocr-base-printed")
model     = VisionEncoderDecoderModel.from_pretrained("microsoft/trocr-base-printed")

print("Loading spaCy NER model...")
nlp = spacy.load("en_core_web_sm")
print("Models ready!\n")

def run_trocr(doc_name):
    lines_dir  = os.path.join(DOCS_DIR, f"{doc_name}_lines")
    line_files = sorted(os.listdir(lines_dir))
    full_text  = []
    for lf in line_files:
        img           = Image.open(os.path.join(lines_dir, lf)).convert("RGB")
        pixel_values  = processor(images=img, return_tensors="pt").pixel_values
        generated_ids = model.generate(pixel_values, max_new_tokens=64)
        text          = processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
        full_text.append(text)
    return " ".join(full_text)

def run_ner(text):
    doc = nlp(text)
    return [(ent.text, ent.label_, spacy.explain(ent.label_)) for ent in doc.ents]

# ── Document definitions ──────────────────────────────────────
documents = [
    {
        "name":     "Invoice #001",
        "doc_name": "doc1_invoice",
        "ground_truth_text": (
            "INVOICE #2026-001 Date: January 13, 2026 Bill To: John Smith "
            "Company: Mapua University Location: Manila, Philippines "
            "Amount Due: $500.00 Due Date: February 1, 2026"
        ),
        "ground_truth_entities": [
            ("January 13, 2026", "DATE"),
            ("John Smith",       "PERSON"),
            ("Mapua University", "ORG"),
            ("Manila",           "GPE"),
            ("Philippines",      "GPE"),
            ("$500.00",          "MONEY"),
            ("February 1, 2026", "DATE"),
        ]
    },
    {
        "name":     "News Article",
        "doc_name": "doc2_news",
        "ground_truth_text": (
            "Microsoft CEO Satya Nadella visited Manila last Monday. "
            "He met with officials from the University of the Philippines. "
            "The meeting took place on January 10, 2026. "
            "A deal worth $2 million was announced. "
            "Google and Amazon were also present at the summit."
        ),
        "ground_truth_entities": [
            ("Microsoft",                     "ORG"),
            ("Satya Nadella",                 "PERSON"),
            ("Manila",                        "GPE"),
            ("University of the Philippines", "ORG"),
            ("January 10, 2026",              "DATE"),
            ("$2 million",                    "MONEY"),
            ("Google",                        "ORG"),
            ("Amazon",                        "ORG"),
        ]
    },
    {
        "name":     "Legal Form",
        "doc_name": "doc3_legal",
        "ground_truth_text": (
            "LEGAL AGREEMENT Party A: Maria Santos "
            "Party B: Accenture Philippines "
            "Date of Agreement: December 5, 2025 "
            "Location: Bonifacio Global City, Taguig "
            "Compensation: PHP 150000.00 Witness: Jose Reyes"
        ),
        "ground_truth_entities": [
            ("Maria Santos",          "PERSON"),
            ("Accenture Philippines", "ORG"),
            ("December 5, 2025",      "DATE"),
            ("Taguig",                "GPE"),
            ("Jose Reyes",            "PERSON"),
        ]
    },
]

# ── Run pipeline ──────────────────────────────────────────────
all_results = []

for doc in documents:
    print("=" * 60)
    print(f"Document: {doc['name']}")
    print("=" * 60)

    # TrOCR extraction line by line
    print("Running TrOCR (line by line)...")
    ocr_text = run_trocr(doc["doc_name"])
    print(f"OCR Output: {ocr_text}\n")

    # NER on OCR output
    ocr_entities = run_ner(ocr_text)
    print(f"NER on OCR Output:")
    print(f"{'Entity Text':<35} {'Label':<12} {'Explanation'}")
    print("-" * 70)
    if ocr_entities:
        for text, label, explanation in ocr_entities:
            print(f"{text:<35} {label:<12} {explanation}")
    else:
        print("  No entities detected.")

    # NER on ground truth text
    gt_entities = run_ner(doc["ground_truth_text"])
    print(f"\nNER on Ground Truth Text:")
    print(f"{'Entity Text':<35} {'Label':<12} {'Explanation'}")
    print("-" * 70)
    if gt_entities:
        for text, label, explanation in gt_entities:
            print(f"{text:<35} {label:<12} {explanation}")
    else:
        print("  No entities detected.")

    all_results.append({
        "name":         doc["name"],
        "ocr_text":     ocr_text,
        "ocr_entities": ocr_entities,
        "gt_entities":  gt_entities,
        "gt_expected":  doc["ground_truth_entities"],
    })
    print()

# ── Error Propagation Analysis ────────────────────────────────
print("=" * 60)
print("ERROR PROPAGATION ANALYSIS")
print("=" * 60)
print(f"\n{'Doc':<15} {'Expected Entity':<30} {'Expected Label':<12} {'Found in OCR NER?'}")
print("-" * 75)

for result in all_results:
    ocr_entity_texts = [e[0].lower() for e in result["ocr_entities"]]
    for expected_text, expected_label in result["gt_expected"]:
        found  = any(expected_text.lower() in t for t in ocr_entity_texts)
        status = "✓ Found" if found else "✗ Missed"
        print(f"{result['name']:<15} {expected_text:<30} {expected_label:<12} {status}")
    print()

print("Done! OCR → NER pipeline complete.")