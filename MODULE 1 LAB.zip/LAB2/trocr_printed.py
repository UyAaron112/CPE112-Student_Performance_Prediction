import os
from transformers import TrOCRProcessor, VisionEncoderDecoderModel
from PIL import Image


print("Loading TrOCR printed model...")
processor = TrOCRProcessor.from_pretrained("microsoft/trocr-base-printed")
model = VisionEncoderDecoderModel.from_pretrained("microsoft/trocr-base-printed")
print("Model ready!\n")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

images = {
    "clean1": os.path.join(BASE_DIR, "clean1.png"),
    "clean2": os.path.join(BASE_DIR, "clean2.png"),
    "clean3": os.path.join(BASE_DIR, "clean3.png"),
}

GROUND_TRUTH = {
    "clean1": "TITANS",
    "clean2": "TITANIC",
    "clean3": "DOLL",
}

print(f"{'Image':<10} {'Ground Truth':<15} {'TrOCR Output'}")
print("-" * 45)

trocr_results = {}
for name, path in images.items():
    img = Image.open(path).convert("RGB")
    pixel_values = processor(images=img, return_tensors="pt").pixel_values
    generated_ids = model.generate(pixel_values)
    generated_text = processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
    trocr_results[name] = generated_text
    print(f"{name:<10} {GROUND_TRUTH[name]:<15} {generated_text}")

print("\nDone! TrOCR printed inference complete.")