from transformers import TrOCRProcessor, VisionEncoderDecoderModel
from datasets import load_dataset
from PIL import Image
import os

print("Loading TrOCR handwritten model...")
processor = TrOCRProcessor.from_pretrained("microsoft/trocr-base-handwritten")
model = VisionEncoderDecoderModel.from_pretrained("microsoft/trocr-base-handwritten")
print("Model ready!\n")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def run_trocr(image):
    pixel_values = processor(images=image.convert("RGB"), return_tensors="pt").pixel_values
    generated_ids = model.generate(pixel_values, max_new_tokens=32)
    return processor.batch_decode(generated_ids, skip_special_tokens=True)[0]

print("Fetching IAM handwritten samples...")
ds = load_dataset("Teklia/IAM-line", split="test", streaming=True)

iam_results = []
print(f"\n{'Label':<15} {'Ground Truth':<25} {'TrOCR HW Output'}")
print("-" * 65)

for i, sample in enumerate(ds):
    if i >= 2:
        break
    img = sample["image"]
    gt  = sample["text"]
    output = run_trocr(img)
    label = f"IAM Sample {i+1}"
    print(f"{label:<15} {gt:<25} {output}")
    iam_results.append((label, gt, output))

print("\n--- Printed images tested on Handwritten model ---")
printed_images = {
    "clean1": ("TITANS",  os.path.join(BASE_DIR, "clean1.png")),
    "clean2": ("TITANIC", os.path.join(BASE_DIR, "clean2.png")),
    "clean3": ("DOLL",    os.path.join(BASE_DIR, "clean3.png")),
}

for name, (gt, path) in printed_images.items():
    img = Image.open(path)
    output = run_trocr(img)
    print(f"{'Printed->' + name:<15} {gt:<25} {output}")

print("\nDone!")