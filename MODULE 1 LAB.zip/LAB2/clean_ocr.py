import easyocr
import os

print("Loading EasyOCR...")
reader = easyocr.Reader(['en'], gpu=False)
print("Ready!\n")

BASE_DIR = os.path.dirname(__file__)

images = {
    "clean1.png": "TITANS",
    "clean2.png": "TITANIC",
    "clean3.png": "DOLL",
}

for img_name, ground_truth in images.items():

    img_path = os.path.join(BASE_DIR, img_name)  # FIXED PATH ISSUE

    result = reader.readtext(img_path)

    print(f"Image       : {img_name}")
    print(f"Ground Truth: {ground_truth}")

    if result:
        for (_, text, conf) in result:
            print(f"Predicted   : {text}")
            print(f"Confidence  : {conf:.2f}")
    else:
        print("Predicted   : (no text detected)")
        print("Confidence  : 0.00")

    print("-" * 40)