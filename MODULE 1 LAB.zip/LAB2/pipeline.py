import os
import string
import warnings
warnings.filterwarnings("ignore", message="'pin_memory'")

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from transformers import TrOCRProcessor, VisionEncoderDecoderModel
from datasets import load_dataset
from PIL import Image

stop_words = set(stopwords.words('english'))

def preprocess(text):
    tokens = word_tokenize(text)
    tokens = [t.lower() for t in tokens]
    tokens = [t for t in tokens if t not in string.punctuation]
    tokens = [t for t in tokens if t not in stop_words]
    return tokens

def run_trocr(model, processor, image):
    pixel_values = processor(images=image.convert("RGB"), return_tensors="pt").pixel_values
    generated_ids = model.generate(pixel_values, max_new_tokens=32)
    return processor.batch_decode(generated_ids, skip_special_tokens=True)[0]

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

print("=" * 60)
print("SECTION 1: TrOCR — Printed Model")
print("=" * 60)

print("Loading microsoft/trocr-base-printed...")
p_processor = TrOCRProcessor.from_pretrained("microsoft/trocr-base-printed")
p_model     = VisionEncoderDecoderModel.from_pretrained("microsoft/trocr-base-printed")

printed_samples = [
    ("clean1", "TITANS",  os.path.join(BASE_DIR, "clean1.png")),
    ("clean2", "TITANIC", os.path.join(BASE_DIR, "clean2.png")),
    ("clean3", "DOLL",    os.path.join(BASE_DIR, "clean3.png")),
]

easyocr_results = {
    "clean1": "TITANS",
    "clean2": "TITANIC",
    "clean3": "DOLL",
}

printed_results = []
print(f"\n{'Image':<10} {'Ground Truth':<15} {'TrOCR Output'}")
print("-" * 40)
for name, gt, path in printed_samples:
    img    = Image.open(path)
    output = run_trocr(p_model, p_processor, img)
    print(f"{name:<10} {gt:<15} {output}")
    printed_results.append((name, "Printed", gt, easyocr_results[name], output))

print("\n" + "=" * 60)
print("SECTION 2: TrOCR — Handwritten Model")
print("=" * 60)

print("Loading microsoft/trocr-base-handwritten...")
h_processor = TrOCRProcessor.from_pretrained("microsoft/trocr-base-handwritten")
h_model     = VisionEncoderDecoderModel.from_pretrained("microsoft/trocr-base-handwritten")

print("\nFetching IAM handwritten samples...")
ds = load_dataset("Teklia/IAM-line", split="test", streaming=True)

hw_results = []
print(f"\n{'Label':<15} {'Ground Truth':<50} {'TrOCR HW Output'}")
print("-" * 100)
for i, sample in enumerate(ds):
    if i >= 2:
        break
    img    = sample["image"]
    gt     = sample["text"]
    output = run_trocr(h_model, h_processor, img)
    label  = f"IAM Sample {i+1}"
    print(f"{label:<15} {gt:<50} {output}")
    hw_results.append((label, "Handwritten", gt, "N/A", output))

print("\n" + "=" * 60)
print("SECTION 3: NLTK Preprocessing")
print("=" * 60)

all_results = printed_results + hw_results

print(f"\n{'Label':<15} {'Type':<13} {'Ground Truth Tokens':<30} {'EasyOCR Tokens':<25} {'TrOCR Tokens'}")
print("-" * 110)
for label, img_type, gt, easy, trocr in all_results:
    gt_tokens    = preprocess(gt)
    easy_tokens  = preprocess(easy) if easy != "N/A" else ["N/A"]
    trocr_tokens = preprocess(trocr)
    print(f"{label:<15} {img_type:<13} {str(gt_tokens):<30} {str(easy_tokens):<25} {str(trocr_tokens)}")

print("\n" + "=" * 60)
print("SECTION 4: Final Comparison Table")
print("=" * 60)
print(f"\n{'Image':<15} {'Type':<13} {'Ground Truth':<30} {'EasyOCR':<20} {'TrOCR':<25} {'Cleaned Tokens (TrOCR)'}")
print("-" * 120)
for label, img_type, gt, easy, trocr in all_results:
    cleaned = str(preprocess(trocr))
    print(f"{label:<15} {img_type:<13} {gt:<30} {easy:<20} {trocr:<25} {cleaned}")

print("\nDone! Full pipeline complete.")